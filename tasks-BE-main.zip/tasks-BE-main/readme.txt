PORT=8080
JWT_SECRET=tasksapi
MONGO_URL='mongodb+srv://yossry:yossry12345@cluster0.xfd2aqq.mongodb.net/tasks?retryWrites=true&w=majority'